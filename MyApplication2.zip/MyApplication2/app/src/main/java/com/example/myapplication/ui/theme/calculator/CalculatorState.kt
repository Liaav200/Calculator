package com.example.myapplication.ui.theme.calculator

data class CalculatorState(
    val text: String =""
)
